let () =
  print_endline "Compiler stub: compiler.ml"